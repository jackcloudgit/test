policy "advisory-module-versions" {
  source            = "./sentinel/advisory-module-versions.sentinel"
  enforcement_level = "advisory"
}