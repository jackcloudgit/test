#!/usr/bin/env bash
set -euo pipefail

# Validates Terraform module version constraints across all .tf files.
# Fails when the same module source is pinned with incompatible constraints.

ROOT_DIR="$(pwd)"
if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  ROOT_DIR="$(git rev-parse --show-toplevel)"
fi

mapfile -t TF_FILES < <(find "$ROOT_DIR" -type f -name "*.tf" -not -path "*/.terraform/*" | sort)

if [[ ${#TF_FILES[@]} -eq 0 ]]; then
  echo "No Terraform files found."
  exit 0
fi

declare -A SOURCE_TO_CONSTRAINTS
declare -A SOURCE_TO_OCCURRENCES
declare -A SOURCE_MISSING_VERSION
errors=0

is_registry_source() {
  local source="$1"

  if [[ "$source" =~ ^(\./|\.\./|/|[A-Za-z]:\\\\|git::|hg::|s3::|gcs::|https?://|github\.com/|bitbucket\.org/) ]]; then
    return 1
  fi

  return 0
}

append_unique_line() {
  local current="$1"
  local candidate="$2"

  if [[ -z "$current" ]]; then
    printf '%s' "$candidate"
    return
  fi

  if grep -Fqx "$candidate" <<< "$current"; then
    printf '%s' "$current"
  else
    printf '%s\n%s' "$current" "$candidate"
  fi
}

for file in "${TF_FILES[@]}"; do
  while IFS=$'\t' read -r module_name source version; do
    [[ -z "${source:-}" ]] && continue

    source="$(echo "$source" | xargs)"
    version="$(echo "${version:-}" | xargs)"

    occurrence="$file :: module \"$module_name\""
    SOURCE_TO_OCCURRENCES["$source"]="$(append_unique_line "${SOURCE_TO_OCCURRENCES[$source]-}" "$occurrence")"

    if is_registry_source "$source" && [[ -z "$version" ]]; then
      SOURCE_MISSING_VERSION["$source"]="$(append_unique_line "${SOURCE_MISSING_VERSION[$source]-}" "$occurrence")"
      continue
    fi

    if [[ -n "$version" ]]; then
      SOURCE_TO_CONSTRAINTS["$source"]="$(append_unique_line "${SOURCE_TO_CONSTRAINTS[$source]-}" "$version")"
    fi
  done < <(
    awk '
      function trim(s) {
        gsub(/^[ \t\r\n]+|[ \t\r\n]+$/, "", s)
        return s
      }

      BEGIN {
        in_module = 0
        module_name = ""
        source = ""
        version = ""
        depth = 0
      }

      {
        line = $0
        sub(/#.*/, "", line)
        sub(/\/\/.*/, "", line)

        if (!in_module) {
          if (match(line, /^[ \t]*module[ \t]+"[^"]+"[ \t]*\{?/)) {
            module_name = line
            sub(/^[ \t]*module[ \t]+"/, "", module_name)
            sub(/"[ \t]*\{?.*$/, "", module_name)
            in_module = 1
            source = ""
            version = ""
            depth = 1
          }
          next
        }

        open_count = gsub(/\{/, "{", line)
        close_count = gsub(/\}/, "}", line)
        depth += open_count - close_count

        if (match(line, /^[ \t]*source[ \t]*=[ \t]*"[^"]+"/)) {
          source = line
          sub(/^[ \t]*source[ \t]*=[ \t]*"/, "", source)
          sub(/".*$/, "", source)
          source = trim(source)
        }

        if (match(line, /^[ \t]*version[ \t]*=[ \t]*"[^"]+"/)) {
          version = line
          sub(/^[ \t]*version[ \t]*=[ \t]*"/, "", version)
          sub(/".*$/, "", version)
          version = trim(version)
        }

        if (depth <= 0) {
          printf "%s\t%s\t%s\n", module_name, source, version
          in_module = 0
          module_name = ""
          source = ""
          version = ""
          depth = 0
        }
      }
    ' "$file"
  )
done

for source in "${!SOURCE_MISSING_VERSION[@]}"; do
  ((errors += 1))
  echo "ERROR: Terraform registry module has no version constraint."
  echo "  Source: $source"
  echo "  Occurrences:"
  while IFS= read -r line; do
    echo "    - $line"
  done <<< "${SOURCE_MISSING_VERSION[$source]}"
  echo

done

for source in "${!SOURCE_TO_CONSTRAINTS[@]}"; do
  constraints="${SOURCE_TO_CONSTRAINTS[$source]}"
  count=$(grep -c '.' <<< "$constraints" || true)

  if (( count > 1 )); then
    ((errors += 1))
    echo "ERROR: Incompatible version constraints detected for the same module source."
    echo "  Source: $source"
    echo "  Constraints found:"
    while IFS= read -r line; do
      [[ -n "$line" ]] && echo "    - $line"
    done <<< "$constraints"
    echo "  Occurrences:"
    while IFS= read -r line; do
      [[ -n "$line" ]] && echo "    - $line"
    done <<< "${SOURCE_TO_OCCURRENCES[$source]-}"
    echo
  fi
done

if (( errors > 0 )); then
  echo "Terraform version constraint validation failed with $errors issue(s)."
  exit 1
fi

echo "Terraform version constraint validation passed."
